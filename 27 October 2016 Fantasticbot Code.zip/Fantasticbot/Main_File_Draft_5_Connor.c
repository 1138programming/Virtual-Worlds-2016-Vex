#pragma config(StandardModel, "RVW Fantasticbot")
#pragma config(RenamedStdModelSensor, I2C_1, rightEncoder)
#pragma config(RenamedStdModelSensor, I2C_2, leftEncoder)
#pragma config(RenamedStdModelSensor, I2C_3, armEncoder)
#pragma config(RenamedStdModelSensor, I2C_4, extensionEncoder)
#pragma config(RenamedStdModelSensor, I2C_5, wristEncoder)
#pragma config(I2C_Usage, I2C1, i2cSensors)
#pragma config(Sensor, in1,    leftLight,      sensorLineFollower)
#pragma config(Sensor, in2,    middleLight,    sensorLineFollower)
#pragma config(Sensor, in3,    rightLight,     sensorLineFollower)
#pragma config(Sensor, in4,    wristPot,       sensorPotentiometer)
#pragma config(Sensor, in6,    gyro,           sensorGyro)
#pragma config(Sensor, dgtl7,  touchSensor,    sensorTouch)
#pragma config(Sensor, dgtl8,  sonarSensor,    sensorSONAR_cm)
#pragma config(Sensor, I2C_1,  rightEncoder,   sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_2,  leftEncoder,    sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_3,  armEncoder,     sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_4,  extensionEncoder, sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_5,  wristEncoder,   sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Motor,  port1,           frontRightMotor, tmotorVex393_HBridge, openLoop, reversed)
#pragma config(Motor,  port2,           rearRightMotor, tmotorVex393_MC29, openLoop, reversed, encoderPort, I2C_1)
#pragma config(Motor,  port3,           frontLeftMotor, tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port4,           rearLeftMotor, tmotorVex393_MC29, openLoop, encoderPort, I2C_2)
#pragma config(Motor,  port6,           clawMotor,     tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port7,           armMotor,      tmotorVex393_MC29, openLoop, encoderPort, I2C_3)
#pragma config(Motor,  port8,           leftExtendMotor, tmotorVex393_MC29, openLoop, encoderPort, I2C_4)
#pragma config(Motor,  port9,           rightExtendMotor, tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port10,          wristMotor,    tmotorVex393_HBridge, openLoop, encoderPort, I2C_5)
#pragma config(I2C_Usage, I2C1, i2cSensors)
#pragma config(Sensor, in1,    leftLight,      sensorLineFollower)
#pragma config(Sensor, in2,    middleLight,    sensorLineFollower)
#pragma config(Sensor, in3,    rightLight,     sensorLineFollower)
#pragma config(Sensor, in4,    wristPot,       sensorPotentiometer)
#pragma config(Sensor, in6,    gyro,           sensorGyro)
#pragma config(Sensor, dgtl7,  touchSensor,    sensorTouch)
#pragma config(Sensor, dgtl8,  sonarSensor,    sensorSONAR_cm)
#pragma config(Sensor, I2C_1,  rightEncoder,   sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_2,  leftEncoder,    sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_3,  armEncoder,     sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_4,  extensionEncoder, sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_5,  wristEncoder,   sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Motor,  port1,           frontRightMotor, tmotorVex393_HBridge, openLoop, reversed)
#pragma config(Motor,  port2,           rearRightMotor, tmotorVex393_MC29, openLoop, reversed, encoderPort, I2C_1)
#pragma config(Motor,  port3,           frontLeftMotor, tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port4,           rearLeftMotor, tmotorVex393_MC29, openLoop, encoderPort, I2C_2)
#pragma config(Motor,  port6,           clawMotor,     tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port7,           armMotor,      tmotorVex393_MC29, openLoop, encoderPort, I2C_3)
#pragma config(Motor,  port8,           leftExtendMotor, tmotorVex393_MC29, openLoop, encoderPort, I2C_4)
#pragma config(Motor,  port9,           rightExtendMotor, tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port10,          wristMotor,    tmotorVex393_HBridge, openLoop, encoderPort, I2C_5)
#pragma config(I2C_Usage, I2C1, i2cSensors)
#pragma config(Sensor, in1,    leftLight,      sensorLineFollower)
#pragma config(Sensor, in2,    middleLight,    sensorLineFollower)
#pragma config(Sensor, in3,    rightLight,     sensorLineFollower)
#pragma config(Sensor, in4,    wristPot,       sensorPotentiometer)
#pragma config(Sensor, in6,    gyro,           sensorGyro)
#pragma config(Sensor, dgtl7,  touchSensor,    sensorTouch)
#pragma config(Sensor, dgtl8,  sonarSensor,    sensorSONAR_cm)
#pragma config(Sensor, I2C_1,  rightEncoder,   sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_2,  leftEncoder,    sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_3,  armEncoder,     sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_4,  extensionEncoder, sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_5,  wristEncoder,   sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Motor,  port1,           frontRightMotor, tmotorVex393_HBridge, openLoop, reversed)
#pragma config(Motor,  port2,           rearRightMotor, tmotorVex393_MC29, openLoop, reversed, encoderPort, I2C_1)
#pragma config(Motor,  port3,           frontLeftMotor, tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port4,           rearLeftMotor, tmotorVex393_MC29, openLoop, encoderPort, I2C_2)
#pragma config(Motor,  port6,           clawMotor,     tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port7,           armMotor,      tmotorVex393_MC29, openLoop, encoderPort, I2C_3)
#pragma config(Motor,  port8,           leftExtendMotor, tmotorVex393_MC29, openLoop, encoderPort, I2C_4)
#pragma config(Motor,  port9,           rightExtendMotor, tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port10,          wristMotor,    tmotorVex393_HBridge, openLoop, encoderPort, I2C_5)
#pragma config(I2C_Usage, I2C1, i2cSensors)
#pragma config(Sensor, in1,    leftLight,      sensorLineFollower)
#pragma config(Sensor, in2,    middleLight,    sensorLineFollower)
#pragma config(Sensor, in3,    rightLight,     sensorLineFollower)
#pragma config(Sensor, in4,    wristPot,       sensorPotentiometer)
#pragma config(Sensor, in6,    gyro,           sensorGyro)
#pragma config(Sensor, dgtl7,  touchSensor,    sensorTouch)
#pragma config(Sensor, dgtl8,  sonarSensor,    sensorSONAR_cm)
#pragma config(Sensor, I2C_1,  rightEncoder,   sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_2,  leftEncoder,    sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_3,  armEncoder,     sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_4,  extensionEncoder, sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Sensor, I2C_5,  wristEncoder,   sensorQuadEncoderOnI2CPort,    , AutoAssign )
#pragma config(Motor,  port1,           frontRightMotor, tmotorVex393_HBridge, openLoop, reversed)
#pragma config(Motor,  port2,           rearRightMotor, tmotorVex393_MC29, openLoop, reversed, encoderPort, I2C_1)
#pragma config(Motor,  port3,           frontLeftMotor, tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port4,           rearLeftMotor, tmotorVex393_MC29, openLoop, encoderPort, I2C_2)
#pragma config(Motor,  port6,           clawMotor,     tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port7,           armMotor,      tmotorVex393_MC29, openLoop, encoderPort, I2C_3)
#pragma config(Motor,  port8,           leftExtendMotor, tmotorVex393_MC29, openLoop, encoderPort, I2C_4)
#pragma config(Motor,  port9,           rightExtendMotor, tmotorVex393_MC29, openLoop)
#pragma config(Motor,  port10,          wristMotor,    tmotorVex393_HBridge, openLoop, encoderPort, I2C_5)
#pragma config(StandardModel, "RVW Fantasticbot")
#pragma config(RenamedStdModelSensor, I2C_1, rightEncoder)
#pragma config(RenamedStdModelSensor, I2C_2, leftEncoder)
#pragma config(RenamedStdModelSensor, I2C_3, armEncoder)
#pragma config(RenamedStdModelSensor, I2C_4, extensionEncoder)
#pragma config(RenamedStdModelSensor, I2C_5, wristEncoder)
//this function moves the wrist motor based off of a certain amount of time
void moveClawForTime(int wristPower, int time)//power to the wrist, time
{
	motor[wristMotor] = wristPower;//move wrist at certain power
	wait1Msec(time);//move wrist for a certain time
}

//This function moves the wrist up until the encoder reaches a certain amount
void moveClawForRotationsUp(int wristEncoderPower, int rotations)
{
	SensorValue[wristEncoder] = 0;//Resets the encoder value on the wrist
	while(SensorValue[wristEncoder] < rotations)
		{
			motor[wristMotor] = wristEncoderPower;//Move the wrist at a certain speed
		}
	motor[wristMotor] = 0;//Stop the wrist
}

//This function moves the wrist down until the encoder reaches a certain amount
void moveClawForRotationsDown(int wristEncoderPowerRev, int negativeRotations)
{
	SensorValue[wristEncoder] = 0;//Resets the encoder value on the wrist
	while(SensorValue[wristEncoder] > -negativeRotations)
		{
			motor[wristMotor] = -wristEncoderPowerRev;//Move the wrist at a certain speed
		}
	motor[wristMotor] = 0;//Stop the wrist
}
//This function moves the arm and the base at the same time at a certain speed for a certain amount of time
void moveBaseAndArm(int baseleftspeed, int baserightspeed, int armspeed, float time)
{
	motor[frontLeftMotor] = baseleftspeed;
	motor[frontRightMotor] = baserightspeed;
	motor[rearLeftMotor] = baseleftspeed;
	motor[rearRightMotor] = baserightspeed;
	motor[armMotor] = armspeed;
	wait1Msec(time*1000);
	motor[frontLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0;
	motor[armMotor] = 0;
}

//This function moves the base and the claw at the same time at a certain speed for a certain amount of time
void moveBaseAndClaw(int baseleftspeed2, int baserightspeed2, int clawdirection, float time2)
{
	motor[frontLeftMotor] = baseleftspeed2;
	motor[frontRightMotor] = baserightspeed2;
	motor[rearLeftMotor] = baseleftspeed2;
	motor[rearRightMotor] = baserightspeed2;
	motor[clawMotor] = -127*clawdirection;
	wait1Msec(time2*1000);
	motor[frontLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0;
	motor[clawMotor] = 0;
}

//This function moves the arm and the claw at the same time at a certain speed for a certain amount of time
void moveArmAndClaw(int armspeed2, int clawdirection2, float time3)
{
	motor[armMotor] = armspeed2;
	motor[clawMotor] = -127*clawdirection2;
	wait1Msec(time3*1000);
	motor[armMotor] = 0;
	motor[clawMotor] = 0;
}

//This function moves the base, arm, and claw at the same time at a ceratin speed for a certain amount of time
void moveBaseArmAndClaw(int baseleftspeed3, int baserightspeed3, int armspeed3, int clawdirection3, float time4)
{
	motor[frontLeftMotor] = baseleftspeed3;
	motor[rearLeftMotor] = baseleftspeed3;
	motor[frontRightMotor] = baserightspeed3;
	motor[rearRightMotor] = baserightspeed3;
	motor[armMotor] = armspeed3;
	motor[clawMotor] = -127*clawdirection3;
	wait1Msec(time4*1000);
	motor[frontLeftMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearRightMotor] = 0;
	motor[armMotor] = 0;
	motor[clawMotor] = 0;
}

//This function moves the base and extension at the same time at a certain speed for a certain amount of time
void moveBaseAndExtension(int baseleftspeed4, int baserightspeed4, int extensionspeed, float time5)
{
	motor[frontLeftMotor] = baseleftspeed4;
	motor[rearLeftMotor] = baseleftspeed4;
	motor[frontRightMotor] = baserightspeed4;
	motor[rearRightMotor] = baserightspeed4;
	motor[leftExtendMotor] = extensionspeed;
	motor[rightExtendMotor] = extensionspeed;
	wait1Msec(time5*1000);
	motor[frontLeftMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearRightMotor] = 0;
	motor[leftExtendMotor] = 0;
	motor[rightExtendMotor] = 0;
}
int topdistance = 902; //Highest distance the encoder on the extension can read
int halfdistance = 451; //Middle distance the encoder on the extension can read
int bottomdistance = 0; //Lowest distance the encoder on the extension can read


//This function uses the extension and moves it for time ---------------------------------------------------------------------------------------
void moveExtensionForTime(int speed, float time)
{
	motor[leftExtendMotor] = speed; //extends arm
	motor[rightExtendMotor] = speed;
	wait1Msec(time*1000); //time spent extending arm
	motor[leftExtendMotor] = 0; //stops the extension
	motor[rightExtendMotor] = 0;
}


//This function uses the extension and moves it up for distance --------------------------------------------------------------------------------
void moveExtensionUpForDistance(int speedup, int distanceup)
{
	SensorValue[extensionEncoder] = 0;
	while(SensorValue[extensionEncoder] < distanceup) //extending arm until distance
	{
		motor[leftExtendMotor] = speedup; //extends arm
		motor[rightExtendMotor] = speedup;
	}
	motor[leftExtendMotor] = 0; //stops the extension
	motor[rightExtendMotor] = 0;
}


//This function uses the extension and moves it down for distance ------------------------------------------------------------------------------
void moveExtensionDownForDistance(int speeddown, int distancedown)
{
	SensorValue[extensionEncoder] = 0;
	while(SensorValue[extensionEncoder] > distancedown) //extending arm until distance
	{
		motor[leftExtendMotor] = -speeddown; //extends arm
		motor[rightExtendMotor] = -speeddown;
	}
	motor[leftExtendMotor] = 0; //stops the extension
	motor[rightExtendMotor] = 0;
}
int openclaw = 1; //Used in moveClawForTime when opening claw
int closeclaw = -1; //Used in moveClawForTime when closing claw


//This function moves the claw open or close for a certain amount of time ----------------------------------------------------------------------
void moveClawForTime(int direction) //direction that the claw motor will move
{
	motor[clawMotor] = -127*direction; //move the claw motor
	wait1Msec(250); //time spent moving the claw motor
	motor[clawMotor] = 0; //stop the claw motor
}
int fullspeed = 127; //Used to make a motor go at full speed forwards
int negativefullspeed = -127; //Used to make a motor go at full speed backwards
int halfspeed = 50; //Used to make a motor go at half speed forwards
int negativehalfspeed = -50; //Used to make a motor go at half speed backwards


//This function moves the base at a certain speed for a certain ammount of time, and then comes to a stop --------------------------------------
void moveBaseForTime(int leftpower, int rightpower, float time) //Power to the left side of the base, power to the right side of the base, time
{
	motor[frontRightMotor] = rightpower;
	motor[frontLeftMotor] = leftpower;
	motor[rearLeftMotor] = leftpower;
	motor[rearRightMotor] = rightpower; //Move the base at a certain power
	wait1Msec(time*1000); //Keep moving until time is up
	motor[frontRightMotor] = 0;
	motor[frontLeftMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0; //Stop the base
}


//This function moves the base forwards until the encoders on the base reach a certain ammount, and then comes to a stop -----------------------
void moveBaseForwardForDistance(int power, int distance) //Power to the base, distance going forwards with encoders
{
	SensorValue[leftEncoder] = 0;
	SensorValue[rightEncoder] = 0; //Reset the encoder values on the base
	while(SensorValue[leftEncoder] < distance || SensorValue[rightEncoder] > -distance) //While the encoders have not reached a certain value
	{
		motor[frontLeftMotor] = power;
		motor[frontRightMotor] = power;
		motor[rearLeftMotor] = power;
		motor[rearRightMotor] = power; //Move the base at a certain speed
	}
	motor[frontLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0; //Stop the base
}


//This function moves the base backwards until the encoders on the base reach a certain ammount, and then comes to a stop ----------------------
void moveBaseBackwardForDistance(int powerreversed, int negativedistance) //Power going to the base reversed, distance going backwards with encoders
{
	SensorValue[leftEncoder] = 0;
	SensorValue[rightEncoder] = 0; //Reset the encoder values on the base
	while(SensorValue[leftEncoder] > -negativedistance || SensorValue[rightEncoder] < negativedistance) //While the encoders have not reached a certain value
	{
		motor[frontLeftMotor] = -powerreversed;
		motor[frontRightMotor] = -powerreversed;
		motor[rearLeftMotor] = -powerreversed;
		motor[rearRightMotor] = -powerreversed; //Move the base at a certain speed
	}
	motor[frontLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0; //Stop the base
}


//This function follows a line for a certain distance using the line followers, then comes to a complete stop ----------------------------------
void followLineForDistance(int speedwhencorrect, int linedistance) //Distance for following the line (How long should I follow the line for?)
{
	SensorValue[leftEncoder] = 0;
	SensorValue[rightEncoder] = 0; //Reset the encoder values on the base
	while(SensorValue[leftEncoder] < linedistance || SensorValue[rightEncoder] > -linedistance) //While the encoders have not reached a certain value
	{
		if(SensorValue[leftLight] > 500 && SensorValue[middleLight] > 500 && SensorValue[rightLight] < 500) //If tracking to the left
		{
			motor[frontLeftMotor] = 60;
			motor[frontRightMotor] = -40;
			motor[rearLeftMotor] = 60;
			motor[rearRightMotor] = -40;
		}
		else if(SensorValue[leftLight] < 500 && SensorValue[middleLight] > 500 && SensorValue[rightLight] > 500) //If tracking to the right
		{
			motor[frontLeftMotor] = -40;
			motor[frontRightMotor] = 60;
			motor[rearLeftMotor] = -40;
			motor[rearRightMotor] = 60;
		}
		else //If going forward perfectly and not tracking left or right
		{
			motor[frontLeftMotor] = speedwhencorrect;
			motor[frontRightMotor] = speedwhencorrect;
			motor[rearLeftMotor] = speedwhencorrect;
			motor[rearRightMotor] = speedwhencorrect;
		}
	}
	motor[frontLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0; //Stop the base
}


//This function moves the base until the line on the field is sensed, then comes to a complete stop --------------------------------------------
void stopAtLine(int speed) //Speed of the base when approaching the line
{
	while(SensorValue[leftLight] > 500 || SensorValue[rightLight] > 500 || SensorValue[middleLight] > 500) //While line isn't sensed
	{
		motor[frontLeftMotor] = speed;
		motor[frontRightMotor] = speed;
		motor[rearLeftMotor] = speed;
		motor[rearRightMotor] = speed; //Move the base at a certain value
	}
	motor[frontLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0; //Stop the base
}


//This function makes a precise right turn using a value in the gyroscope ----------------------------------------------------------------------
void turnRightWithGyro(int speed, int turnradius) //Speed of the base when turning right, amount of turn
{
	SensorValue[gyro] = 0; //Reset the value of the gyro
	while(SensorValue[gyro] < turnradius*10) //While the gyro is not at the certain radius assigned
	{
		motor[frontLeftMotor] = speed;
		motor[frontRightMotor] = -speed;
		motor[rearLeftMotor] = speed;
		motor[rearRightMotor] = -speed; //Turn right at a certain speed
	}
	motor[frontLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0; //Stop the base
}


//This function makes a precise left turn using a value in the gyroscope -----------------------------------------------------------------------
void turnLeftWithGyro(int speedreversed, int turnradiusreversed) //Speed of the base when turning left, amount of turn
{
	SensorValue[gyro] = 0; //Reset the value of the gyro
	while(SensorValue[gyro] > turnradiusreversed*10) //While the gyro is not at the certain radius assigned
	{
		motor[frontLeftMotor] = -speedreversed;
		motor[frontRightMotor] = speedreversed;
		motor[rearLeftMotor] = -speedreversed;
		motor[rearRightMotor] = speedreversed; //Turn left at a certain speed
	}
	motor[frontLeftMotor] = 0;
	motor[frontRightMotor] = 0;
	motor[rearLeftMotor] = 0;
	motor[rearRightMotor] = 0; //Stop the base
}


//This function approaches an object until a certain value on the ultrasound is reached --------------------------------------------------------
void approachObjectWithUltrasound(int speedapproaching, int distanceaway) //Speed of approaching the object, distance from object to stop at
{
	while(SensorValue[sonarSensor] > distanceaway)
	{
		motor[frontLeftMotor] = speedapproaching;
		motor[frontRightMotor] = speedapproaching;
		motor[rearLeftMotor] = speedapproaching;
		motor[rearRightMotor] = speedapproaching; //Speed coming up to wall
	}
}
//This function moves the arm motor based off of a certain amount of time
void moveArmForTime(int armPower, int time)
{
	motor[armMotor] = armPower;//move arm at certain power
	wait1Msec(time);//move arm for a certain time
}

//This function moves the wrist up until the encoder reaches a certain amount
void moveArmForRotationsUp(int armEncoderPower, int rotations)
{
	SensorValue[armEncoder] = 0;//Resets the encoder value on the arm
	while(SensorValue[armEncoder] < rotations)
		{
			motor[armMotor] = armEncoderPower;//Move the wrist at a certain speed
		}
	motor[armMotor] = 0;//Stop the arm
}

//This function moves the arm down until the encoder reaches a certain amount
void moveArmForRotationsDown(int armEncoderPowerRev, int negativeRotations)
{
	SensorValue[armEncoder] = 0;//Resets the encoder value on the arm
	while(SensorValue[armEncoder] > -negativeRotations)
		{
			motor[armMotor] = -armEncoderPowerRev;//Move the arm at a certain speed
		}
	motor[armMotor] = 0;//Stop the arm
}
task main()
{



}
